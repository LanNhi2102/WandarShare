const testimonials = [
  {
    id: 1,
    img: "/assets/images/testimonial/1.png",
    name: "Augusta Silva",
    designation: "Sales Manager",
    text: `Aliquam dictum elit vitae mauris facilisis at dictum urna dignissim donec vel lectus vel felis.`,
    feedback: "",
  },
  {
    id: 2,
    img: "/assets/images/testimonial/2.png",
    name: "Augusta Silva",
    designation: "Sales Manager",
    text: `Aliquam dictum elit vitae mauris facilisis at dictum urna dignissim donec vel lectus vel felis.`,
    feedback: "",
  },
  {
    id: 3,
    img: "/assets/images/testimonial/3.png",
    name: "Augusta Silva",
    designation: "Sales Manager",
    text: `Aliquam dictum elit vitae mauris facilisis at dictum urna dignissim donec vel lectus vel felis.`,
    feedback: "",
  },
  {
    id: 4,
    img: "/assets/images/testimonial/4.png",
    name: "Augusta Silva",
    designation: "Sales Manager",
    text: `Aliquam dictum elit vitae mauris facilisis at dictum urna dignissim donec vel lectus vel felis.`,
    feedback: "",
  },
  {
    id: 5,
    img: "/assets/images/testimonial/5.png",
    name: "Augusta Silva",
    designation: "Sales Manager",
    text: `Aliquam dictum elit vitae mauris facilisis at dictum urna dignissim donec vel lectus vel felis.`,
    feedback: "",
  },
  {
    id: 6,
    img: "/assets/images/testimonial/6.png",
    name: "Augusta Silva",
    designation: "Sales Manager",
    text: `Aliquam dictum elit vitae mauris facilisis at dictum urna dignissim donec vel lectus vel felis.`,
    feedback: "",
  },
  {
    id: 7,
    name: "Lara Croft",
    designation: "Restaurant Owner",
    text: `Especially i want to give thanks to support team, this guys are
      friendly, correct, gave me quick and complete answers.`,
    feedback: "Good job!",
  },
  {
    id: 8,
    name: "Ali Tufan",
    designation: "Restaurant Owner",
    text: `Especially i want to give thanks to support team, this guys are
      friendly, correct, gave me quick and complete answers.`,
    feedback: "Good job!",
  },
  {
    id: 9,
    name: "Jara Binte",
    designation: "Restaurant Owner",
    text: `Especially i want to give thanks to support team, this guys are
      friendly, correct, gave me quick and complete answers.`,
    feedback: "Good job!",
  },
  {
    id: 10,
    name: "Lara Croft",
    designation: "Restaurant Owner",
    text: `Especially i want to give thanks to support team, this guys are
      friendly, correct, gave me quick and complete answers.`,
    feedback: "Good job!",
  },
  {
    id: 11,
    name: "Ali Tufan",
    designation: "Restaurant Owner",
    text: `Especially i want to give thanks to support team, this guys are
      friendly, correct, gave me quick and complete answers.`,
    feedback: "Good job!",
  },
  {
    id: 12,
    name: "Jara Binte",
    designation: "Restaurant Owner",
    text: `Especially i want to give thanks to support team, this guys are
      friendly, correct, gave me quick and complete answers.`,
    feedback: "Good job!",
  },
];
export default testimonials