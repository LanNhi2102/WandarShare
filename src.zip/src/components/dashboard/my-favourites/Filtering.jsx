const Filtering = () => {
  return (
    <select className="selectpicker show-tick form-select c_select">
      <option>All</option>
      <option>Exchange</option>
      <option>Rent</option>
    </select>
  );
};

export default Filtering;
