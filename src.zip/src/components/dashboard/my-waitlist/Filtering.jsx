const Filtering = () => {
  return (
    <select className="selectpicker show-tick form-select c_select">
      <option>All</option>
      <option>Peding</option>
      <option>Finished</option>
    </select>
  );
};

export default Filtering;
