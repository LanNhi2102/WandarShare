const Ratings = () => {
  return (
    <>
      <li className="list-inline-item">
        <a href="#">
          <i className="fa fa-star"></i>
        </a>
      </li>
      <li className="list-inline-item">
        <a href="#">
          <i className="fa fa-star"></i>
        </a>
      </li>
      <li className="list-inline-item">
        <a href="#">
          <i className="fa fa-star"></i>
        </a>
      </li>
      <li className="list-inline-item">
        <a href="#">
          <i className="fa fa-star"></i>
        </a>
      </li>
      <li className="list-inline-item">
        <a href="#">
          <i className="fa fa-star-o"></i>
        </a>
      </li>
    </>
  );
};

export default Ratings;
